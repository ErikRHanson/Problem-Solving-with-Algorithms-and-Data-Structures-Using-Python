from pythonds.basic.stack import Stack

s = Stack()

s.push(33)
print(s.size())