class OrderedList:
    def __init__(self):
        self.head = None
