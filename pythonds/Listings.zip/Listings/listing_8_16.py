from random import randrange
def flip():
    return randrange(2)
