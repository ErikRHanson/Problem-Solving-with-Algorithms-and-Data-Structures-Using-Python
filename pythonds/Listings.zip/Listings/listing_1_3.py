   def show(self):
        print(self.num,"/",self.den)
