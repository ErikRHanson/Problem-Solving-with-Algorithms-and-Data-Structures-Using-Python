    def __init__(self):
        self.heapList = [0]
        self.currentSize = 0
