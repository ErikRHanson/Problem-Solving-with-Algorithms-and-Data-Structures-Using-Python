def moveDisk(fp,tp):
	print("moving disk from %d to %d\n" % (fp,tp))
