def sumOfN3(n):
   return (n*(n+1))/2
