def listsum(numList):
    theSum = 0
    for i in numList:
        theSum = theSum + i
    return theSum    
